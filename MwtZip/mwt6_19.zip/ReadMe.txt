
                   Molecular Weight Calculator

    This program will calculate the molecular weight and percent
composition of up to 20 compounds simultaneously.  It recognizes
user-definable abbreviations and all isotopes.  It also includes a
Mole/Mass Converter, Formula Finder, Capillary Flow Modeler, Amino 
Acid Notation Converter, Peptide Sequence Fragmentation Modeler, 
and built-in calculator.  Full program documentation is available 
by pressing F1 during program operation.  This program is FreeWare 
and may be distributed freely.

    You can manually install the Molecular Weight Calculator for
9x/NT/00/ME/XP only if you already have the MSVBVM60.Dll file in
your Windows System directory.  Otherwise, please download the file
with the setup program from:
    http://www.alchemistmatt.com/mwtwin.html#autoinstall

To manually install, unzip the files into a program directory, for
example "C:\PROGRAM FILES\MWTWIN".  If replacing an older version, you
do not need to replace the MWTWIN.INI, MWT_VALU.INI, or .DAT files.  Do 
not move the MSFLXGRD.OCX, COMDLG32.OCX, RICHTX32.OCX, or RICHED32.DLL 
files to your \Windows\System or \Winnt\System32 directory since 
Windows will give an error message saying they are not registered correctly.

Send E-Mail to AlchemistMatt@Yahoo.Com or Matt@Alchemistmatt.Com
WWW is at http://www.alchemistmatt.com/
and http://www.geocities.com/tandm_wy/
and http://come.to/alchemistmatt/



