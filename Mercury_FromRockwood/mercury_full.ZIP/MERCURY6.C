/*=====================================================================*/
/* Program MERCURY2.C                                                  */
/*                                                                     */
/* MERCURY6 is a version of MERCURY5 that omitts outputing flanking    */
/* zeros in the ouput file.                                            */
/* MERCURY5 is a version of MERCURY2 using (mostly) double percision.  */
/* instead of floating point arithmatic. It gives more accurate        */
/* intensity values than MERCURY2.                                     */
/* MERCURY2 is an integer based version of MERCURY, although most of   */
/* the arithmetic is floating point. Using integer (changed to float)  */
/* values for isotopic masses, the calculation can be performed with   */
/* a much smaller data set and is extremely fast.  The ASCII output    */
/* file is a stick representation of the mass spectrum. There is no    */
/* ultrahigh resolution mode in this program.                          */
/*                                                                     */
/* Algorithm by       Alan L. Rockwood                                 */
/* Programming by     Steve Van Orden                                  */
/*=====================================================================*/
 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <alloc.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include <io.h>
#include <time.h>
 
#define PI      3.14159265358979323846
#define TWOPI   6.28318530717958647
#define HALFPI  1.57079632679489666
#define ProtonMass   1.00727649
#define ElectronMass 0.00054858
#define MAXAtomNo    103		/* allows for elements H - Lr */
#define MAXIsotopes  20			/* allows for 20 elements in molecular formula */
#define EZS Element[Z].Symbol
#define EZNI Element[Z].NumIsotopes
#define EZM Element[Z].IsoMass
#define EZI Element[Z].IntMass
#define EZP Element[Z].IsoProb
#define EZW Element[Z].WrapMass
#define EZNA Element[Z].NumAtoms
 
typedef struct
{
   char  Symbol[3];	/* Elemental symbol */
   int	 NumIsotopes;	/* Number of stable isotopes */
   float *IsoMass;	/* Array of isotopic masses */
   int   *IntMass;	/* Array of integer isotopic masses */
   float *IsoProb;	/* Array of isotopic probabilities */
   int   *WrapMass;	/* Array of wrap-around masses */
   long  NumAtoms;	/* Number of occurances of element in molecular formula */
 
} Atomic;
 
Atomic	Element[MAXAtomNo+1];	/* 104 elements allows for Z=103 or Lr */
int	AtomicNum[MAXIsotopes];	/* Atomic numbers of elements parsed from molecular formula */
 
/*************************************************/
/* FUNCTION Intro - called by main()             */
/*************************************************/
void Intro()
{
   clrscr();
   gotoxy(6,1);
   printf("�������������������������������������������������������������������ͻ");
   gotoxy(6,2);
   printf("�                         M E R C U R Y  I I                        �");
   gotoxy(6,3);
   printf("�                                                                   �");
   gotoxy(6,4);
   printf("�  An Integer based Fourier transform isotopic distibution program  �");
   gotoxy(6,5);
   printf("�������������������������������������������������������������������ͼ");
   printf("\n\n      Usage:\n");
   printf("        1. Entering Molecular (Ionic) Formula\n");
   printf("             - Group all occurances for each element (no parenthesis)\n");
   printf("             - Input is case sensitive (e.g. use H, C, Na, Cl, etc.)\n");
   printf("             - Account for charge carrying species in an ionic formula by\n");
   printf("               adding/subtracting H, Na, K, etc. from the neutral formula\n");
   printf("        2. All elements (H through Lr) are available\n");
   printf("        3. Both positive and negative (multiple) charges can be used\n\n");
   printf("      Algorithm by : Alan L. Rockwood\n");
   printf("      Program by   : Steven L. Van Orden\n");
   printf("      Developed at : Pacific Northwest Laboratories / Battelle Northwest\n");
   printf("                     in the laboratory of Richard D. Smith\n");
 
}  /* End of Intro() */
 
/*************************************************/
/* FUNCTION InitializeData - called by main()    */
/*************************************************/
void InitializeData()
{
   FILE *ElementFile;
   int  i, Z;
 
   if ((ElementFile = fopen("ISOTOPE.DAT", "rt")) == NULL)
   {
      printf("\nError - Cannot open File: ISOTOPE.DAT\n");
      exit(-1);
   }
   for (Z=1; Z<=MAXAtomNo; Z++)
   {
      EZS[0]=EZS[1]=EZS[2]=NULL;
      fscanf(ElementFile,"%2s %d\n", &EZS,&EZNI);
      EZM = malloc((EZNI+1) * sizeof(float));
      EZI = malloc((EZNI+1) * sizeof(int));
      EZP = malloc((EZNI+1) * sizeof(float));
      for (i=0; i<EZNI; i++)
      {
       fscanf(ElementFile, "%f \n", &EZM[i]);
       fscanf(ElementFile, "%f \n", &EZP[i]);
       EZI[i] = (int)(EZM[i] + 0.5);
      }
      EZNA = 0;
      EZM[EZNI] = NULL;
      EZP[EZNI] = NULL;
      fscanf(ElementFile, " \n");
   }
   fclose(ElementFile);
 
}
 
/*************************************************/
/* FUNCTION CalcVariances - called by main()     */
/*************************************************/
CalcVariances(double *MolVar, double *IntMolVar, int NumElements)
{
   int i, j, Z;
   double Var, IntVar;
   double avemass, intavemass;
 
   *MolVar = *IntMolVar = 0;
   for (i=0; i<NumElements; i++)
   {
      Z = AtomicNum[i];
      avemass = intavemass = 0;
      for (j=0; j<EZNI; j++)
      {
	 avemass += EZM[j] * EZP[j];
	 intavemass += EZI[j] * EZP[j];
      }
      Var = IntVar = 0;
      for (j=0; j<EZNI; j++)
      {
	 Var += (EZM[j] - avemass) * (EZM[j] - avemass) * EZP[j];
	 IntVar += (EZI[j] - intavemass) * (EZI[j] - intavemass) * EZP[j];
      }
      *MolVar += EZNA * Var;
      *IntMolVar += EZNA * IntVar;
   }
 
}  /* End of CalcVariances() */
 
/*************************************************/
/* FUNCTION CalcMassRange - called by main()     */
/*************************************************/
void CalcMassRange(int *MassRange, double MolVar, int charge, int type)
{
   int i;
 
   if ((type == 1) || (charge == 0)) *MassRange = sqrt(1+MolVar)*10;
   else  *MassRange = sqrt(1+MolVar)*10/charge;  /* +/- 5 sd's : Multiply charged */
 
   /* Set to nearest (upper) power of 2 */
   for (i=1024; i>0; i/=2)
   {
      if (i < *MassRange)
      {
	 *MassRange = i * 2;
	 i = 0;
      }
   }
 
}  /* End of CalcMassRange() */
 
/*************************************************/
/* FUNCTION AddElement - called by ParseMF()     */
/*************************************************/
void AddElement(char Atom[3], int Ecount, long Acount)
{
   int Z, FOUND=0;
 
   for (Z=1; Z<=(MAXAtomNo); Z++)
   {
      if (strcmp(Atom,EZS) == 0)
      {
       if (EZNA != 0)
       {
	 printf("\nError - the element %s has been entered twice in molecular formula\n", EZS);
         exit(-1);
       }
       else
       {
          AtomicNum[Ecount] = Z;  /* AtomicNum is global */
	  EZNA = Acount;
	  EZW = malloc((EZNI+1)*sizeof(int));
	  EZW[EZNI] = NULL;
          Z=MAXAtomNo+1;
	  FOUND=1;
       }
      }
   }
   if (!FOUND)
   {
      printf("\nError - Unknown element in Molecular Formula\n");
      exit(-1);
   }
}
 
/*************************************************/
/* FUNCTION ParseMF - called by main()           */
/*************************************************/
int ParseMF(char MF[], int *elementcount)
{
   int  i, COND, ERRFLAG;
   long atomcount;
   char Atom[3], ch, errorch;
 
   atomcount=0; COND=0; ERRFLAG=0;
   Atom[0] = Atom[1] = Atom[2] = NULL;
   for (i=0; i<=strlen(MF); i++)
   {
      ch = MF[i];
      if (isspace(ch)) ch = NULL;
      switch (COND)
      {
	 case 0: if (isupper(ch))
		  {
		     Atom[0] = ch;
		     COND = 1;
		  }
		  else
		  {
		    COND = -1;
		    errorch = ch;
		  }
		  break;  /* out of case 0 */
 
	  case 1: if (isupper(ch))
		  {
		     AddElement(Atom,(*elementcount)++,1);
		     Atom[0] = NULL;
		     COND = 0;
		     i--;
		  }
		  else
		  {
		     if (islower(ch))
		     {
			Atom[1] = ch;
			COND = 2;
		     }
		     else
		     {
			if (isdigit(ch))
			{
			   atomcount = atoi(&ch);
			   COND = 3;
			}
			else
			{
			   if (ch == NULL)
			   {
			      AddElement(Atom,(*elementcount)++,1);
			   }
			   else
			   {
			      COND = -1;
			      errorch = ch;
			   }
			}
		     }
		  }
		  break;  /* out of case 1 */
 
	  case 2: if (isupper(ch))
		  {
		     AddElement(Atom,(*elementcount)++,1);
		     Atom[0] = ch; Atom[1] = NULL;
		     COND = 1;
                  }
                  else
		  {
                     if (isdigit(ch))
                     {
			atomcount = atoi(&ch);
                        COND = 3;
                     }
                     else
                     {
			if (ch == NULL)  AddElement(Atom,(*elementcount)++,1);
			else
			{
			   COND = -1;
			   errorch = ch;
			}
		     }
                  }
                  break;  /* out of case 2 */
 
	  case 3: if (isupper(ch))
		  {
		     AddElement(Atom,(*elementcount)++,atomcount);
		     atomcount = 0;
		     Atom[0] = Atom[1] = NULL;
		     COND = 0;
		     i--;
                  }
                  else
                  {
		     if (isdigit(ch)) atomcount = atomcount*10+atoi(&ch);
                     else
		     {
			if (ch == NULL)
			{
			   AddElement(Atom,(*elementcount)++,atomcount);
			   COND = 0;
			}
			else
			{
			   COND = -1;
			   errorch = ch;
			}
		     }
                  }
		  break;  /* out of case 3 */
 
	 case -1: ERRFLAG = -1;
		  i = strlen(MF) + 1;  /* skip out of loop */
                  break;  /* out ot case -1 */
 
      }  /* end switch */
   }  /* end for i ... */
   if (ERRFLAG)
   {
      printf("\nError in format of input...  The character '%c' is invalid\n",errorch);
      printf("Hit any key to continue...");
      getch();
      return(-1);
   }
   else return(0);
}
 
/*************************************************/
/* FUNCTION CalcFreq - called by main()          */
/*    Could be done with less code, but this     */
/*    saves a few operations.                    */
/*************************************************/
void CalcFreq(double FreqData[], int Ecount, long NumPoints, int MassRange, long MassShift)
{
   int    i, j, k, Z;
   double real, imag, freq, X, theta, r, tempr;
   double a, b, c, d;
 
   /* Calculate first half of Frequency Domain (+)masses */
   for (i=1; i<=NumPoints/2; i++)
   {
      freq = (double)(i-1)/MassRange;
      r = 1;
      theta = 0;
      for (j=0; j<Ecount; j++)
      {
	 Z = AtomicNum[j];
	 real = imag = 0;
	 for (k=0; k<EZNI; k++)
	 {
	    X = TWOPI * EZI[k] * freq;
	    real += EZP[k] * cos(X);
	    imag += EZP[k] * sin(X);
	 }
 
	 /* Convert to polar coordinates, r then theta */
	 tempr = sqrt(real*real+imag*imag);
	 r *= pow(tempr,EZNA);
	 if (real > 0) theta += EZNA * atan(imag/real);
	 else if (real < 0) theta += EZNA * (atan(imag/real) + PI);
	      else if (imag > 0) theta += EZNA * HALFPI;
		   else theta += EZNA * -HALFPI;
 
      }  /* end for(j) */
 
      /* Convert back to real:imag coordinates and store */
      a = r * cos(theta);
      b = r * sin(theta);
      c = cos(TWOPI*MassShift*freq);
      d = sin(TWOPI*MassShift*freq);
      FreqData[2*i-1] = a*c - b*d; /* real data in odd index */
      FreqData[2*i] = b*c + a*d;   /* imag data in even index */
 
   }  /* end for(i) */
 
   /* Calculate second half of Frequency Domain (-)masses */
   for (i=NumPoints/2+1; i<=NumPoints; i++)
   {
      freq = (double)(i-NumPoints-1)/MassRange;
      r = 1;
      theta = 0;
      for (j=0; j<Ecount; j++)
      {
	 Z = AtomicNum[j];
	 real = imag = 0;
	 for (k=0; k<EZNI; k++)
	 {
	    X = TWOPI * EZI[k] * freq;
	    real += EZP[k] * cos(X);
	    imag += EZP[k] * sin(X);
	 }
 
	 /* Convert to polar coordinates, r then theta */
	 tempr = sqrt(real*real+imag*imag);
	 r *= pow(tempr,EZNA);
	 if (real > 0) theta += EZNA * atan(imag/real);
	 else if (real < 0) theta += EZNA * (atan(imag/real) + PI);
	      else if (imag > 0) theta += EZNA * HALFPI;
		   else theta += EZNA * -HALFPI;
 
      }  /* end for(j) */
 
      /* Convert back to real:imag coordinates and store */
      a = r * cos(theta);
      b = r * sin(theta);
      c = cos(TWOPI*MassShift*freq);
      d = sin(TWOPI*MassShift*freq);
      FreqData[2*i-1] = a*c - b*d; /* real data in odd index */
      FreqData[2*i] = b*c + a*d;   /* imag data in even index */
 
   }  /* end of for(i) */
 
}  /* End of CalcFreq() */
 
/*************************************************/
/* FUNCTION Four1 - called by main()             */
/*    Taken from Numerical Recipies in C, 2nd Ed */
/*    Changed to work with double (not float).   */
/*    If isign=1 FFT, isign=-1 IFFT              */
/*************************************************/
void Four1(double Data[], unsigned long nn, int isign)
{
   unsigned long i, j, m, n, mmax, istep;
   double wr, wpr, wpi, wi, theta;
   double wtemp, tempr, tempi;
 
   /* Perform bit reversal of Data[] */
   n = nn << 1;
   j=1;
   for (i=1; i<n; i+=2)
   {
      if (j > i)
      {
	 wtemp = Data[i];
	 Data[i] = Data[j];
	 Data[j] = wtemp;
	 wtemp = Data[i+1];
	 Data[i+1] = Data[j+1];
	 Data[j+1] = wtemp;
      }
      m = n >> 1;
      while (m >= 2 && j > m)
      {
	 j -= m;
	 m >>= 1;
      }
      j += m;
   }
 
   /* Perform Danielson-Lanczos section of FFT */
   n = nn << 1;
   mmax = 2;
   while (n > mmax)  /* Loop executed log(2)nn times */
   {
      istep = mmax << 1;
      theta = isign * (TWOPI/mmax);  /* Initialize the trigonimetric recurrance */
      wtemp = sin(0.5*theta);
      wpr = -2.0*wtemp*wtemp;
      wpi = sin(theta);
      wr = 1.0;
      wi = 0.0;
      for (m=1; m<mmax; m+=2)
      {
	 for (i=m; i<=n; i+=istep)
	 {
	    j = i+mmax;                       /* The Danielson-Lanczos formula */
	    tempr = wr*Data[j]-wi*Data[j+1];
	    tempi = wr*Data[j+1]+wi*Data[j];
	    Data[j] = Data[i]-tempr;
	    Data[j+1] = Data[i+1]-tempi;
	    Data[i] += tempr;
	    Data[i+1] += tempi;
	 }
	 wr = (wtemp=wr)*wpr-wi*wpi+wr;
	 wi = wi*wpr+wtemp*wpi+wi;
      }
      mmax = istep;
   }
 
   /* Normalize if FT */
   if (isign == 1)
     for (i=1; i<=nn; i++)
     {
	Data[2*i-1] /= nn;
	Data[2*i] /= nn;
     }
 
}  /* End of Four1() */
 
/*************************************************/
/* FUNCTION OutputData - called by main()        */
/*************************************************/
void OutputData(FILE *filename, double Data[], int NumPoints, int PtsPerAmu,
		float MW, float tempMW, long intMW, long MIintMW, int charge,
		double MolVar, double IntMolVar)
{
   int i;
   double mass, maxint=0, ratio, CorrIntMW;
 
   /* Normalize intensity to 0%-100% scale */
   for (i=1; i<2*NumPoints; i+=2)
   {
      if (Data[i] > maxint) maxint = Data[i];
   }
   for (i=1; i<2*NumPoints; i+=2)
   {
      Data[i] = 100 * Data[i]/maxint;
   }
 
   if (IntMolVar == 0) ratio = 1;
   else ratio = sqrt(MolVar) / sqrt(IntMolVar);
   CorrIntMW = tempMW * ratio;
   for (i=NumPoints/2+1; i<=NumPoints; i++)
   {
      mass = (double)(i-NumPoints-1)/PtsPerAmu + intMW;
/*      mass += MIMW - MIintMW; */
      mass *= ratio;
      mass += MW - CorrIntMW;
      mass /= charge;
      fprintf(filename,"%lf %lf\n",mass,Data[2*i-1]);
   }
   for (i=1; i<=NumPoints/2; i++)
   {
      mass = (double)(i-1)/PtsPerAmu + intMW;
/*      mass += MW - MIintMW; */
      mass *= ratio;
      mass += MW - CorrIntMW;
      mass /= charge;
      fprintf(filename,"%lf %lf\n",mass,Data[2*i-1]);
   }
 
   fclose(filename);
 
}  /* End of OutputData() */
 
 
/*************************************************/
/* FUNCTION main() - main block of FFTISO        */
/*************************************************/
void main()
{
   int 	 j, k, Z;
   int	 NumElements=0;			/* Number of elements in molecular formula */
   int	 Charge;			/* Charge on ion */
   int	 MassRange;
   int   PtsPerAmu;
   long  NumPoints;			/* Working # of datapoints (real:imag) */
   char  ch;
   char  Chargeval[4];			/* Input strings for charge */
   char	 MolForm[41];			/* 40 characters max in molecular formula */
   char	 filename[60];			/* Name of output file */
   FILE	 *outfile;			/* output file pointer */
   double *FreqData;			/* Array of real:imaginary frequency values for FFT */
   float MW;
   double MIMW, tempMW, MolVar, IntMolVar;
   long intMW, MIintMW;
   clock_t start, end;
   float time, seconds;
   int	minutes;
 
   /**********************************************************************/
   /*  Beginning of main code block                                      */
   /**********************************************************************/
   InitializeData();
   Intro();
 
   MolForm[0]='\0';
   while (MolForm[0] == '\0')
   {
     gotoxy(1,21);
     printf("Molecular Formula:                                         ");
     printf("\n\n(Enter to exit)                                          \n");
     printf("                           ");
     gotoxy(20,21);
     gets(MolForm);
     if (strlen(MolForm) == 0)
     {
	printf("\n\n\n");
	exit(0);
     }
     if (ParseMF(MolForm,&NumElements) == -1)
     {
	MolForm[0] = '\0';
	NumElements = 0;
     }
   }
 
   gotoxy(1,23);
   printf("                  ");
   gotoxy(1,22);
   printf("Charge: 1      ");
   gotoxy(9,22);
   gets(Chargeval);
   if (strlen(Chargeval) == 0)  Charge = 1;
   else Charge = atoi(Chargeval);
 
   MW = MIMW = tempMW = 0; intMW = MIintMW = 0;
   for (j=0; j<NumElements; j++)
   {
      Z = AtomicNum[j];
      for (k=0; k<EZNI; k++)
      {
	 MW += EZNA * EZM[k] * EZP[k];
	 tempMW += EZNA * EZI[k] * EZP[k];
	 if (k==0)
	 {
	    MIMW += EZNA * EZM[k];
	    MIintMW += EZNA * EZI[k];
	 }
      }
   }
   MW -= ElectronMass * Charge;
   tempMW -= ElectronMass * Charge;
   MIMW -= ElectronMass * Charge;
   intMW = (long)(tempMW+0.5);
   if (Charge != 0)
   {
      printf("Average Molecular Weight: %.3lf, at m/z: %.3f\n",MW,MW/fabs(Charge));
      printf("Average Integer MW: %ld, at m/z: %.3f\n\n",intMW,(float)intMW/fabs(Charge));
   }
   else
   {
      printf("Average Molecular Weight: %.3lf\n",MW);
      printf("Average Integer MW: %ld\n\n",intMW);
   }
 
 
   /* Calculate mass range to use based on molecular variance */
   CalcVariances(&MolVar,&IntMolVar,NumElements);
   CalcMassRange(&MassRange,MolVar,Charge,1);
   PtsPerAmu = 1;
 
   /* Allocate memory for Axis arrays */
   NumPoints = MassRange * PtsPerAmu;
   if((FreqData = malloc((2*NumPoints+1)*sizeof(double))) == NULL)
   {
      printf("\nMemory allocation error!\n");
      exit(1);
   }
 
   printf("\n\n");
   filename[0] = NULL;
   while (filename[0] == NULL)
   {
      gotoxy(1,23);
      printf("Filename for output:                                     \n");
      gotoxy(22,23);
      gets(filename);
      if (access(filename,0) == 0)
      {
	 gotoxy(1,24);
	 printf("File exists! Overwrite (Y/N)? N");
	 gotoxy(31,24);
	 ch = toupper(getch());
	 if ((ch == 'N') || ((int)ch == 13))
	 {
	    filename[0] = NULL;
	    gotoxy(1,24);
	    printf("                                ");
	 }
	 else
	 {
	    gotoxy(1,24);
	    printf("                                ");
	 }
      }
   }
   if ((outfile = fopen(filename,"w")) == NULL)
   {
      printf("\nError - Cannot create file %s\n",filename);
      exit(-1);
   }
 
   /* Start isotope distribution calculation */
   start = clock();
   CalcFreq(FreqData,NumElements,NumPoints,MassRange,-intMW);
 
   Four1(FreqData,NumPoints,-1);
   end = clock();
   time = (end - start) / CLK_TCK;
   minutes = (int)(time/60);
   seconds = time - (60*minutes);
   printf("\nCalculation performed in %d min %.3f sec\n",minutes,seconds);
 
   if (Charge == 0) Charge = 1;
   OutputData(outfile,FreqData,NumPoints,PtsPerAmu,MW,tempMW,intMW,MIintMW,fabs(Charge),MolVar,IntMolVar);
 
   fclose(outfile);
 
   free(FreqData);
   exit(0);
 
}  /* End of Program FFTISO.C */
