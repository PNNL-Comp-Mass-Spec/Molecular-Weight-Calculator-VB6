/*====================================================================*/
/* Program MERCURY.C      version 0.1                                 */
/*                                                                    */
/* MERCURY is an isotope distribution generator based on Fourier      */
/* transform methods.  The calculation is performed by generating the */
/* transformed mass (or mu-domain) for the input molecule which is    */
/* then inverse Fourier transformed into the mass spectrum.  The FFT  */
/* routine is taken from Numerical Recipes in C, 2nd ed. by Press,    */
/* Teukolsky, Vetterling, and Flannery, Cambridge Univ. Press. This   */
/* program can be used to swiftly calculate high resolution and       */
/* ultrahigh resolution (a mass defect spectrum of a single isotopic  */
/* peak) distributions.   The program outputs an ASCII file of mass   */
/* intensity pairs. The output file does not account for the electron */
/* mass, but the interactive display does. (We'll fix that in a later */
/* version.) When running an ultrahigh resolution calculation, do not */
/* use zero charge or you will get bogus output. Also, when it asks   */
/* for the mass shift in ultrahigh resolution mode, it expects you to */
/* feed it a negative number. The high resolution calculations are    */
/* very fast (typically a second on a 66 MHz '486), but ultrahigh     */
/* resolution calculations are rather slow (several  minutes for a    */
/* single isotope peak.) Overall, the program is good, but could be   */
/* simplified and also optimized to run several times faster.         */
/*                                                                    */
/* Algorithm by : Alan L. Rockwood                                    */
/* Program by   : Steven L. Van Orden                                 */
/* Developed at : Pacific Northwest Laboratories / Battelle Northwest */
/*                in the laboratory directed by Richard D. Smith      */
/*====================================================================*/
 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <alloc.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include <io.h>
#include <time.h>
 
#define PI      3.14159265358979323846
#define TWOPI   6.28318530717958647
#define HALFPI  1.57079632679489666
#define GAUSSIAN 1
#define LORENTZIAN 2
#define ProtonMass   1.00727649
#define ElectronMass 0.00054858
#define MAXAtomNo    103		/* allows for elements H - Lr */
#define MAXIsotopes  20			/* allows for 20 elements in molecular formula */
#define EZS Element[Z].Symbol
#define EZNI Element[Z].NumIsotopes
#define EZM Element[Z].IsoMass
#define EZP Element[Z].IsoProb
#define EZW Element[Z].WrapMass
#define EZNA Element[Z].NumAtoms
 
typedef struct
{
   char  Symbol[3];	/* Elemental symbol */
   int	 NumIsotopes;	/* Number of stable isotopes */
   float *IsoMass;	/* Array of isotopic masses */
   float *IsoProb;	/* Array of isotopic probabilities */
   double *WrapMass;	/* Array of wrap-around masses */
   long   NumAtoms;	/* Number of occurances of element in molecular formula */
 
} Atomic;
 
Atomic	Element[MAXAtomNo+1];	/* 104 elements allows for Z=103 or Lr */
int	AtomicNum[MAXIsotopes];	/* Atomic numbers of elements parsed from molecular formula */
 
/*************************************************/
/* FUNCTION Intro - called by main()             */
/*************************************************/
void Intro()
{
   textattr(LIGHTGRAY + (BLACK<<4));
   clrscr();
   window(1,1,80,6);
   gotoxy(10,1);
   printf("���������������������������������������������������������ͻ");
   gotoxy(10,2);
   printf("�                                                         �");
   gotoxy(10,3);
   printf("�                                                         �");
   gotoxy(10,4);
   printf("�                                                         �");
   gotoxy(10,5);
   printf("���������������������������������������������������������ͼ");
   gotoxy(33,2);
   printf("M E R C U R Y");
   gotoxy(12,4);
   printf("A Fourier transform based isotopic distribution program");
   window(1,7,80,25);
   gotoxy(1,1);
   printf("     Usage:\n");
   printf("       1. Entering Molecular (Ionic) Formula\n");
   printf("            - Group all occurances for each element (no parenthesis)\n");
   printf("            - Input is case sensitive (e.g. use H, C, Na, Cl, etc.)\n");
   printf("            - Account for charge carrying species in an ionic formula by\n");
   printf("              addition/subtraction of H, Na, etc. from the neutral formula\n");
   printf("       3. All elements (H through Lr) are available\n");
   printf("       4. Both positive and negative (multiple) charges can be used\n\n");
   printf("     Algorithm by : Alan L. Rockwood\n");
   printf("     Program by   : Steven L. Van Orden\n");
   printf("     Developed at : Pacific Northwest Laboratories / Battelle Northwest\n");
   printf("                    in the laboratory of Richard D. Smith\n\n");
 
}  /* End of Intro() */
 
/*************************************************/
/* FUNCTION InitializeData - called by main()    */
/*************************************************/
void InitializeData()
{
   FILE *ElementFile;
   int  i, Z;
 
   if ((ElementFile = fopen("ISOTOPE.DAT", "rt")) == NULL)
   {
      printf("\nError - Cannot open File: ISOTOPE.DAT\n");
      exit(-1);
   }
   for (Z=1; Z<=MAXAtomNo; Z++)
   {
      EZS[0]=EZS[1]=EZS[2]=NULL;
      fscanf(ElementFile,"%2s %d\n", &EZS,&EZNI);
      EZM = malloc((EZNI+1) * sizeof(float));
      EZP = malloc((EZNI+1) * sizeof(float));
      for (i=0; i<EZNI; i++)
      {
       fscanf(ElementFile, "%f \n", &EZM[i]);
       fscanf(ElementFile, "%f \n", &EZP[i]);
      }
      EZNA = 0;
      EZM[EZNI] = NULL;
      EZP[EZNI] = NULL;
      fscanf(ElementFile, " \n");
   }
   fclose(ElementFile);
}
 
/*************************************************/
/* FUNCTION CalcVariances - called by main()     */
/*************************************************/
void CalcVariances(float *MolVar, int NumElements)
{
   int i, j, Z;
   float Var, avemass;
 
   *MolVar = 0;
   for (i=0; i<NumElements; i++)
   {
      Z = AtomicNum[i];
      avemass = 0;
      for (j=0; j<EZNI; j++)  avemass += EZM[j] * EZP[j];
      Var = 0;
      for (j=0; j<EZNI; j++)  Var += (EZM[j] - avemass) * (EZM[j] - avemass) * EZP[j];
      *MolVar += EZNA * Var;
   }
 
}  /* End of CalcVariances() */
 
/*************************************************/
/* FUNCTION CalcMassRange - called by main()     */
/*************************************************/
void CalcMassRange(int *MassRange, float MolVar, int charge, int type)
{
   int i;
 
   if ((type == 1) || (charge == 0)) *MassRange = sqrt(1+MolVar)*10;
   else  *MassRange = sqrt(1+MolVar)*10/charge;  /* +/- 5 sd's : Multiply charged */
 
   /* Set to nearest (upper) power of 2 */
   for (i=1024; i>0; i/=2)
   {
      if (i < *MassRange)
      {
	 *MassRange = i * 2;
	 i = 0;
      }
   }
 
}  /* End of CalcMassRange() */
 
/*************************************************/
/* FUNCTION AddElement - called by ParseMF()     */
/*************************************************/
void AddElement(char Atom[3], int Ecount, long Acount)
{
   int Z, FOUND=0;
 
   for (Z=1; Z<=(MAXAtomNo); Z++)
   {
      if (strcmp(Atom,EZS) == 0)
      {
       if (EZNA != 0)
       {
	 printf("\nError - the element %s has been entered twice in molecular formula\n", EZS);
         exit(-1);
       }
       else
       {
          AtomicNum[Ecount] = Z;  /* AtomicNum is global */
	  EZNA = Acount;
	  EZW = malloc((EZNI+1)*sizeof(double));
	  EZW[EZNI] = NULL;
          Z=MAXAtomNo+1;
          FOUND=1;
       }
      }
   }
   if (!FOUND)
   {
      printf("\nError - Unknown element in Molecular Formula\n");
      exit(-1);
   }
}
 
/*************************************************/
/* FUNCTION ParseMF - called by main()           */
/*************************************************/
int ParseMF(char MF[], int *elementcount)
{
   int  i, COND, ERRFLAG;
   long atomcount;
   char Atom[3], ch, errorch;
 
   atomcount=0; COND=0; ERRFLAG=0;
   Atom[0] = Atom[1] = Atom[2] = NULL;
   for (i=0; i<=strlen(MF); i++)
   {
      ch = MF[i];
      if (isspace(ch)) ch = NULL;
      switch (COND)
      {
	 case 0: if (isupper(ch))
		  {
		     Atom[0] = ch;
		     COND = 1;
		  }
		  else
		  {
		    COND = -1;
		    errorch = ch;
		  }
		  break;  /* out of case 0 */
 
	  case 1: if (isupper(ch))
		  {
		     AddElement(Atom,(*elementcount)++,1);
		     Atom[0] = NULL;
		     COND = 0;
		     i--;
		  }
		  else
		  {
		     if (islower(ch))
		     {
			Atom[1] = ch;
			COND = 2;
		     }
		     else
		     {
			if (isdigit(ch))
			{
			   atomcount = atoi(&ch);
			   COND = 3;
			}
			else
			{
			   if (ch == NULL)
			   {
			      AddElement(Atom,(*elementcount)++,1);
			   }
			   else
			   {
			      COND = -1;
			      errorch = ch;
			   }
			}
		     }
		  }
		  break;  /* out of case 1 */
 
	  case 2: if (isupper(ch))
		  {
		     AddElement(Atom,(*elementcount)++,1);
		     Atom[0] = ch; Atom[1] = NULL;
		     COND = 1;
                  }
                  else
                  {
                     if (isdigit(ch))
                     {
			atomcount = atoi(&ch);
                        COND = 3;
                     }
                     else
                     {
			if (ch == NULL)  AddElement(Atom,(*elementcount)++,1);
			else
			{
			   COND = -1;
			   errorch = ch;
			}
		     }
                  }
                  break;  /* out of case 2 */
 
	  case 3: if (isupper(ch))
		  {
		     AddElement(Atom,(*elementcount)++,atomcount);
		     atomcount = 0;
		     Atom[0] = Atom[1] = NULL;
		     COND = 0;
		     i--;
                  }
                  else
                  {
		     if (isdigit(ch)) atomcount = atomcount*10+atoi(&ch);
                     else
		     {
			if (ch == NULL)
			{
			   AddElement(Atom,(*elementcount)++,atomcount);
			   COND = 0;
			}
			else
			{
			   COND = -1;
			   errorch = ch;
			}
		     }
                  }
		  break;  /* out of case 3 */
 
	 case -1: ERRFLAG = -1;
		  i = strlen(MF) + 1;  /* skip out of loop */
                  break;  /* out ot case -1 */
 
      }  /* end switch */
   }  /* end for i ... */
   if (ERRFLAG)
   {
      printf("\nError in format of input...  The character '%c' is invalid\n",errorch);
      printf("Hit any key to continue...");
      getch();
      return(-1);
   }
   else return(0);
}
 
/*************************************************/
/* FUNCTION MassWrap - called by main()          */
/*************************************************/
void MassWrap(int Ecount, int Charge, int MassRange)
{
   int    i, j, Z;
   double avemass;
 
   if (Charge == 0) Charge = 1;
   for (i=0; i<Ecount; i++)
   {
      Z = AtomicNum[i];
      avemass = 0;
      if (EZNI > 1)
      {
	 for (j=0; j<EZNI; j++)  avemass += EZM[j]*EZP[j];
	 avemass /= Charge;
	 for (j=0; j<EZNI; j++)
	 {
	    EZW[j] = EZM[j]/Charge - avemass;
	    if (EZW[j] < 0) EZW[j] += MassRange;
	 }
      }
      else EZW[0] = 0;
   }
 
}  /* End of MassWrap() */
 
/*************************************************/
/* FUNCTION CalcFreq - called by main()          */
/*    Could be done with less code, but this     */
/*    saves a few operations.                    */
/*************************************************/
void CalcFreq(double FreqData[], int Ecount, long NumPoints, int MassRange)
{
   long   i;
   int    j,k,Z;
   double real,imag,freq,X,theta,r,tempr;
 
   /* Calculate first half of Frequency Domain (+)masses */
   for (i=1; i<=NumPoints/2; i++)
   {
      freq = (double)(i-1)/MassRange;
      r = 1;
      theta = 0;
      for (j=0; j<Ecount; j++)
      {
	 Z = AtomicNum[j];
	 real = imag = 0;
	 for (k=0; k<EZNI; k++)
	 {
	    X = TWOPI * EZW[k] * freq;
	    real += EZP[k] * cos(X);
	    imag += EZP[k] * sin(X);
	 }
 
	 /* Convert to polar coordinates, r then theta */
	 tempr = sqrt(real*real+imag*imag);
	 r *= pow(tempr,EZNA);
	 if (real > 0) theta += EZNA * atan(imag/real);
	 else if (real < 0) theta += EZNA * (atan(imag/real) + PI);
	      else if (imag > 0) theta += EZNA * HALFPI;
		   else theta += EZNA * -HALFPI;
 
      }  /* end for(j) */
 
      /* Convert back to real:imag coordinates and store */
      FreqData[2*i-1] = r * cos(theta);  /* real data in odd index */
      FreqData[2*i] = r * sin(theta);	/* imag data in even index */
 
   }  /* end for(i) */
 
   /* Calculate second half of Frequency Domain (-)masses */
   for (i=NumPoints/2+1; i<=NumPoints; i++)
   {
      freq = (double)(i-NumPoints-1)/MassRange;
      r = 1;
      theta = 0;
      for (j=0; j<Ecount; j++)
      {
	 Z = AtomicNum[j];
	 real = imag = 0;
	 for (k=0; k<EZNI; k++)
	 {
	    X = TWOPI * EZW[k] * freq;
	    real += EZP[k] * cos(X);
	    imag += EZP[k] * sin(X);
	 }
 
	 /* Convert to polar coordinates, r then theta */
	 tempr = sqrt(real*real+imag*imag);
	 r *= pow(tempr,EZNA);
	 if (real > 0) theta += EZNA * atan(imag/real);
	 else if (real < 0) theta += EZNA * (atan(imag/real) + PI);
	      else if (imag > 0) theta += EZNA * HALFPI;
		   else theta += EZNA * -HALFPI;
 
      }  /* end for(j) */
 
      /* Convert back to real:imag coordinates and store */
      FreqData[2*i-1] = r * cos(theta); /* real data in even index */
      FreqData[2*i] = r * sin(theta);   /* imag data in odd index */
 
   }  /* end of for(i) */
 
}  /* End of CalcFreq() */
 
/*************************************************/
/* FUNCTION CalcSingle - called by UltraHigh()   */
/*    A single "inverse mass" calculation from   */
/*    CalcFreq(); called MANY times.             */
/*************************************************/
void CalcSingle(int Ecount, double inv_mass, double Point[])
{
   int    i,j,Z;
   double real,imag,X,theta,r,tempr;
 
   r = 1;
   theta = 0;
   for (i=0; i<Ecount; i++)
   {
      Z = AtomicNum[i];
      real = imag = 0;
      for (j=0; j<EZNI; j++)
      {
	 X = TWOPI * EZM[j] * inv_mass;
	 real += EZP[j] * cos(X);
	 imag += EZP[j] * sin(X);
      }
 
      /* Convert to polar coordinates, r then theta */
      tempr = sqrt(real*real + imag*imag);
      r *= pow(tempr,EZNA);
      if (real > 0) theta += EZNA * atan(imag/real);
      else if (real < 0) theta += EZNA * (atan(imag/real) + PI);
	   else if (imag > 0) theta += EZNA * HALFPI;
		else theta += EZNA * -HALFPI;
 
   }  /* end for(i) */
 
   /* Convert back to real:imag coordinates and store*/
   Point[0] = r * cos(theta);  /* return real data  */
   Point[1] = r * sin(theta);  /* return imag data */
 
}  /* End of CalcSingle() */
 
/*************************************************/
/* FUNCTION UltraHigh - called by main()         */
/*************************************************/
void UltraHigh(double Data[], long *NumPoints, float zoomwidth, double pointspace,
	       int Ecount, double MassShift)
{
   int i, j, sumpoint, count, percent;
   double delta, zw_inv;
   double Point[2], a, b, c, d;
   double curr_inv_mass, start_inv_mass;
   double *weight, max;
 
   if (*NumPoints != 2048)
   {
      realloc(Data,4096*sizeof(double));  /* 2048 real, 2048 imag */
      *NumPoints = 2048;
   }
 
   /* Calculate weights for point-summation function */
   sumpoint = (int)((10/(PI*zoomwidth))/pointspace);
   if ((sumpoint % 2) == 0) sumpoint++;
   if ((weight = malloc(sumpoint*sizeof(double))) == NULL)
   {
      printf("\nMemory allocation error!\n");
      exit(-1);
   }
 
   zw_inv = (double)1 / (PI * zoomwidth);
   delta = 5 * zw_inv;
   for (i=0; i<=(sumpoint-1)/2; i++)
   {
      weight[i] = 1/(zw_inv * sqrt(2*PI)) * exp(-0.5 * (delta/zw_inv) * (delta/zw_inv));
      weight[sumpoint-i-1] = weight[i];
      delta -= pointspace;
   }
   max = weight[(sumpoint-1)/2];
   for (i=0; i<sumpoint; i++)  weight[i] /= max;
 
   /* Perform summation of single point calculations for each datapoint */
   printf("\nFiltering and Decimating:\n");
   gotoxy(27,18);
   percent = 0;
   curr_inv_mass = start_inv_mass = -pointspace * ((sumpoint-1)/2);
   for (i=1; i<=(*NumPoints)/2; i++)
   {
      Data[2*i-1] = 0;
      Data[2*i] = 0;
      if (!(i%204))
      {
	 percent += 10;
	 gotoxy(27,18);
	 printf("%d%%",percent);
      }
      for (j=0; j<sumpoint; j++)
      {
	 CalcSingle(Ecount,curr_inv_mass,Point);
	 /* Perform complex multiplication, then weight */
	 a = Point[0];
	 b = Point[1];
	 c = cos(TWOPI*MassShift*curr_inv_mass);
	 d = sin(TWOPI*MassShift*curr_inv_mass);
	 Point[0] = (a * c - b * d) * weight[j];
	 Point[1] = (b * c + a * d) * weight[j];
 
	 Data[2*i-1] += Point[0];  /* real */
	 Data[2*i] += Point[1];    /* imag */
	 curr_inv_mass += pointspace;
      }
      curr_inv_mass = start_inv_mass + (double)1/zoomwidth;
      start_inv_mass += (double)1/zoomwidth;
   }
 
   curr_inv_mass = start_inv_mass = -(double)1/zoomwidth - pointspace * ((sumpoint-1)/2);
   count = 0;
   for (i=*NumPoints; i>=(*NumPoints)/2+1; i--)
   {
      Data[2*i-1] = 0;
      Data[2*i] = 0;
      count++;
      if (!(count%204))
      {
	 percent += 10;
	 gotoxy(27,18);
	 printf("%d%%",percent);
      }
      for (j=0; j<sumpoint; j++)
      {
	 CalcSingle(Ecount,curr_inv_mass,Point);
	 /* Perform complex multiplication, then weight */
	 a = Point[0];
	 b = Point[1];
	 c = cos(TWOPI*MassShift*curr_inv_mass);
	 d = sin(TWOPI*MassShift*curr_inv_mass);
	 Point[0] = (a * c - b * d) * weight[j];
	 Point[1] = (b * c + a * d) * weight[j];
 
	 Data[2*i-1] += Point[0];  /* real */
	 Data[2*i] += Point[1];    /* imag */
	 curr_inv_mass += pointspace;
      }
      curr_inv_mass = start_inv_mass - (double)1/zoomwidth;
      start_inv_mass -= (double)1/zoomwidth;
   }
 
   printf("\n");
   free(weight);
 
}  /* End of UltraHigh() */
 
/*************************************************/
/* FUNCTION Four1 - called by main()             */
/*    Taken from Numerical Recipies in C, 2nd Ed */
/*    Changed to work with double (not float).   */
/*    If isign=1 FFT, isign=-1 IFFT              */
/*************************************************/
void Four1(double Data[], unsigned long nn, int isign)
{
   unsigned long i, j, m, n, mmax, istep;
   double wr, wpr, wpi, wi, theta;
   double wtemp, tempr, tempi;
 
   /* Perform bit reversal of Data[] */
   n = nn << 1;
   j=1;
   for (i=1; i<n; i+=2)
   {
      if (j > i)
      {
	 wtemp = Data[i];
	 Data[i] = Data[j];
	 Data[j] = wtemp;
	 wtemp = Data[i+1];
	 Data[i+1] = Data[j+1];
	 Data[j+1] = wtemp;
      }
      m = n >> 1;
      while (m >= 2 && j > m)
      {
	 j -= m;
	 m >>= 1;
      }
      j += m;
   }
 
   /* Perform Danielson-Lanczos section of FFT */
   n = nn << 1;
   mmax = 2;
   while (n > mmax)  /* Loop executed log(2)nn times */
   {
      istep = mmax << 1;
      theta = isign * (TWOPI/mmax);  /* Initialize the trigonimetric recurrance */
      wtemp = sin(0.5*theta);
      wpr = -2.0*wtemp*wtemp;
      wpi = sin(theta);
      wr = 1.0;
      wi = 0.0;
      for (m=1; m<mmax; m+=2)
      {
	 for (i=m; i<=n; i+=istep)
	 {
	    j = i+mmax;                       /* The Danielson-Lanczos formula */
	    tempr = wr*Data[j]-wi*Data[j+1];
	    tempi = wr*Data[j+1]+wi*Data[j];
	    Data[j] = Data[i]-tempr;
	    Data[j+1] = Data[i+1]-tempi;
	    Data[i] += tempr;
	    Data[i+1] += tempi;
	 }
	 wr = (wtemp=wr)*wpr-wi*wpi+wr;
	 wi = wi*wpr+wtemp*wpi+wi;
      }
      mmax = istep;
   }
 
   /* Normalize if FT */
   if (isign == 1)
     for (i=1; i<=nn; i++)
     {
	Data[2*i-1] /= nn;
	Data[2*i] /= nn;
     }
 
}  /* End of Four1() */
 
/*************************************************/
/* FUNCTION Apodize - called by main()           */
/*    ApType = 1 : Gaussian                      */
/*           = 2 : Lorentzian                    */
/*           = 3 : ??                            */
/*           = -1 : Unapodize Gaussian           */
/*************************************************/
void Apodize(double Data[], long datapoints, long Resolution, int ApType,
	       float sub)
{
   long i;
   double ApVal, expdenom;
 
   if (ApType == 1)  /* Gaussian */
   {
      for (i=1; i<=datapoints; i++)
      {
	 expdenom = ((double)datapoints/sub)*((double)datapoints/sub);
	 if (i <= datapoints/2) ApVal = exp(-(i-1)*(i-1)/expdenom);
	 else ApVal = exp(-(i-datapoints-1)*(i-datapoints-1)/expdenom);
	 Data[2*i-1] *= ApVal;
	 Data[2*i] *= ApVal;
      }
   }
 
   if (ApType == 2)  /* Lorentzian */
   {
      for (i=1; i<=datapoints; i++)
      {
	 if (i <= datapoints/2) ApVal = exp(-(double)(i-1)*(sub/1250.0));
	 else ApVal = exp((double)(i-datapoints-1)*(sub/1250.0));
	 Data[2*i-1] *= ApVal;
	 Data[2*i] *= ApVal;
      }
   }
 
   if (ApType == -1)  /* Unapodize Gaussian */
   {
      for (i=1; i<=datapoints; i++)
      {
	 expdenom = ((double)datapoints/sub)*((double)datapoints/sub);
	 if (i <= datapoints/2) ApVal = exp(-(i-1)*(i-1)/expdenom);
	 else ApVal = exp(-(i-datapoints-1)*(i-datapoints-1)/expdenom);
	 Data[2*i-1] /= ApVal;
	 Data[2*i] /= ApVal;
      }
   }
 
}  /* End of Apodize() */
 
/*************************************************/
/* FUNCTION OutputData - called by main()        */
/*************************************************/
void OutputData(FILE *filename, double Data[], int NumPoints, int PtsPerAmu,
		float MW, int charge)
{
   int i;
   double mass, maxint=0;
 
   /* Normalize intensity to 0%-100% scale */
   for (i=1; i<2*NumPoints; i+=2)
   {
      if (Data[i] > maxint) maxint = Data[i];
   }
   for (i=1; i<2*NumPoints; i+=2)
   {
      Data[i] = 100 * Data[i]/maxint;
   }
 
   for (i=NumPoints/2+1; i<=NumPoints; i++)
   {
      mass = ((double)(i-NumPoints-1)/PtsPerAmu + MW) / charge;
      fprintf(filename,"%lf %lf\n",mass,Data[2*i-1]);
/*      fprintf(filename,"%d %lf %lf\n",i,Data[2*i-1],Data[2*i]); */
   }
   for (i=1; i<=NumPoints/2; i++)
   {
      mass = ((double)(i-1)/PtsPerAmu + MW) / charge;
      fprintf(filename,"%lf %lf\n",mass,Data[2*i-1]);
/*      fprintf(filename,"%d %lf %lf\n",i,Data[2*i-1],Data[2*i]); */
   }
   fclose(filename);
 
}  /* End of OutputData() */
 
 
/*************************************************/
/* FUNCTION main() - main block of FFTISO        */
/*************************************************/
void main()
{
   int 	 j, k, Z;
   int	 NumElements=0;			/* Number of elements in molecular formula */
   int	 Charge;			/* Charge on ion */
   int   ApType;			/* The type of apodization to use */
   int	 MassRange;
   int   PtsPerAmu;
   long  NumPoints;			/* Working # of datapoints (real:imag) */
   long  Resolution;			/* Resolution used in appodization */
   char  ch;
   char  Chargeval[4];			/* Input strings for charge */
   char  tempval[8];			/* Input string for threshold */
   char	 MolForm[41];			/* 40 characters max in molecular formula */
   char	 filename[60];			/* Name of output file */
   FILE	 *outfile;			/* output file pointer */
   float Ap_subscript;			/* Subscript used in apodization function */
   float ZoomWidth;
   float MolVar;
   double *FreqData;			/* Array of real:imaginary frequency values for FFT */
   double MW;
   double MassShift;
   clock_t start, end;
   float time, seconds;
   int	minutes;
 
   /**********************************************************************/
   /*  Beginning of main code block                                      */
   /**********************************************************************/
   InitializeData();
   Intro();
 
   MolForm[0]='\0';
   while (MolForm[0] == '\0')
   {
     gotoxy(1,15);
     printf("Molecular Formula:                                         ");
     printf("\n\n(Enter to exit)                                          \n");
     printf("                           ");
     gotoxy(20,15);
     gets(MolForm);
     if (strlen(MolForm) == 0)
     {
	window(1,1,80,25);
	gotoxy(1,24);
	exit(0);
     }
     if (ParseMF(MolForm,&NumElements) == -1)
     {
	MolForm[0] = '\0';
	NumElements = 0;
     }
   }
 
   gotoxy(1,17);
   printf("                 ");
   gotoxy(1,16);
   printf("Charge: 1      ");
   gotoxy(9,16);
   gets(Chargeval);
   if (strlen(Chargeval) == 0)  Charge = 1;
   else Charge = atoi(Chargeval);
 
   MW = 0;
   for (j=0; j<NumElements; j++)
   {
      Z = AtomicNum[j];
      for (k=0; k<EZNI; k++) MW += EZNA * EZP[k] * EZM[k];
   }
   MW -= ElectronMass * Charge;
   printf("Average Molecular Weight: %.3lf\n\n",MW);
 
   /* Calculate mass range to use based on molecular variance */
   CalcVariances(&MolVar,NumElements);
   CalcMassRange(&MassRange,MolVar,fabs(Charge),0);
   PtsPerAmu = 2048 / MassRange;  /* Use maximum of 2048 real, 2048 imag points */
 
   /* Allocate memory for Axis arrays */
   NumPoints = MassRange * PtsPerAmu;
   if((FreqData = malloc((2*NumPoints+1)*sizeof(double))) == NULL)
   {
      printf("\nMemory allocation error!\n");
      exit(1);
   }
 
   printf("\n\n");
   filename[0] = NULL;
   while (filename[0] == NULL)
   {
      gotoxy(1,17);
      printf("Filename for output:                                     \n");
      gotoxy(22,17);
      gets(filename);
      if (access(filename,0) == 0)
      {
	 gotoxy(1,18);
	 printf("File Exists! Overwrite (Y/N)? N");
	 printf("\b");
	 ch = toupper(getch());
	 if ((ch == 'N') || ((int)ch == 13))
	 {
	    filename[0] = NULL;
	    gotoxy(1,18);
	    printf("                               ");
	 }
	 else
	 {
	    gotoxy(1,18);
	    printf("                               ");
	 }
      }
   }
   if ((outfile = fopen(filename,"w")) == NULL)
   {
      printf("\nError!  Cannot create file %s\n",filename);
      exit(-1);
   }
 
   printf("\n\n");
   gotoxy(1,18);
   printf("Subscript for use in Apodiztion (default is 8): ");
   gets(tempval);
   if (strlen(tempval) == 0)
   {
      Ap_subscript = 8;
      gotoxy(49,18);
      printf("%.2f\n",Ap_subscript);
   }
   else  Ap_subscript = atof(tempval);
 
   /* Start isotope distribution calculation */
   start = clock();
   MassWrap(NumElements,fabs(Charge),MassRange);
   CalcFreq(FreqData,NumElements,NumPoints,MassRange);
 
   /* Apodize data */
   ApType = GAUSSIAN;
/*   ApType = LORENTZIAN; */
   Resolution = 1;  /* Not used yet */
   Apodize(FreqData,NumPoints,Resolution,ApType,Ap_subscript);
 
   Four1(FreqData,NumPoints,-1);
   end = clock();
   time = (end - start) / CLK_TCK;
   minutes = (int)(time/60);
   seconds = time - (60*minutes);
   printf("\nCalculation performed in %d min %.2f sec\n",minutes,seconds);
 
   printf("\nUltra-High Resolution on a peak (Y/N)? N");
   printf("\b");
   ch = toupper(getch());
   if (ch == 'Y')
   {
      printf("%c\n",ch);
      printf("\nMass Range for High Resolution (default is 0.2): ");
      gets(tempval);
      if (strlen(tempval) == 0)
      {
	 ZoomWidth = 0.2;
	 gotoxy(50,18);
	 printf("%.2f\n",ZoomWidth);
      }
      else ZoomWidth = fabs(atof(tempval));
 
      printf("Mass Shift (default is -Average Molecular Weight): ");
      gets(tempval);
      if (strlen(tempval) == 0)
      {
	 MassShift = -MW;
	 gotoxy(52,18);
	 printf("-%.3f\n",MW);
      }
      else MassShift = atof(tempval);
 
      start = clock();
      if (abs(Charge) > 1)  CalcMassRange(&MassRange,MolVar,fabs(Charge),1);
      UltraHigh(FreqData,&NumPoints,ZoomWidth,(double)1/MassRange,NumElements,MassShift*fabs(Charge));
      PtsPerAmu = 2048/ZoomWidth;
 
      /* Apodize data */
      ApType = GAUSSIAN;
      Resolution = 1;  /* Not used yet */
      Apodize(FreqData,NumPoints,Resolution,ApType,Ap_subscript);
 
      Four1(FreqData,NumPoints,-1);
      end = clock();
      time = (end - start) / CLK_TCK;
      minutes = (int)(time/60);
      seconds = time - (60*minutes);
      printf("\nUltraHigh Resolution calculation performed in: %d min %.2f sec\n",minutes,seconds);
   }
 
   if (Charge == 0) Charge = 1;
   if (ch == 'Y') OutputData(outfile,FreqData,NumPoints,PtsPerAmu,-MassShift*fabs(Charge),fabs(Charge));
   else OutputData(outfile,FreqData,NumPoints,PtsPerAmu,MW/fabs(Charge),1);
 
   fclose(outfile);
 
   free(FreqData);
   exit(0);
 
}  /* End of Program FFTISO.C */
